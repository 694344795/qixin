/**
 * @fileOverview imagezoom
 */
KISSY.add("imagezoom", function(S, ImageZoom) {
    return ImageZoom;
}, {requires:[
    "imagezoom/base",
    "imagezoom/autorender"
]});